# models/maqsam_api_section.py

from odoo import models, fields, api
from odoo.exceptions import ValidationError

class MaqsamAPISection(models.Model):
    _name = 'maqsam.api.section'
    _description = 'Maqsam API Documentation Section'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'complete_name'
    _order = 'complete_name'

    name = fields.Char(string='Section Name', required=True, tracking=True)
    complete_name = fields.Char('Complete Name', compute='_compute_complete_name', store=True)
    description = fields.Text(string='Description', tracking=True)
    parent_id = fields.Many2one('maqsam.api.section', string='Parent Section', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_ids = fields.One2many('maqsam.api.section', 'parent_id', string='Subsections')
    content = fields.Html(string='Content', sanitize=True, tracking=True)
    section_type = fields.Selection([
        ('general', 'General'),
        ('authentication', 'Authentication'),
        ('endpoint', 'Endpoint'),
        ('ivr', 'IVR')
    ], string='Section Type', default='general', required=True, tracking=True)
    sequence = fields.Integer(string='Sequence', default=10)
    
    endpoint_ids = fields.One2many('maqsam.api.endpoint', 'section_id', string='Endpoints')

    @api.depends('name', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for section in self:
            if section.parent_id:
                section.complete_name = '%s / %s' % (section.parent_id.complete_name, section.name)
            else:
                section.complete_name = section.name

    @api.constrains('parent_id')
    def _check_hierarchy(self):
        if not self._check_recursion():
            raise ValidationError('Error! You cannot create recursive sections.')

    def name_get(self):
        result = []
        for section in self:
            name = section.complete_name or section.name
            result.append((section.id, name))
        return result