# __manifest__.py

{
    'name': 'Maqsam API Documentation',
    'version': '1.0',
    'category': 'Technical',
    'summary': 'Manage and display Maqsam API documentation',
    'sequence': 10,
    'author': 'Your Company',
    'website': 'https://www.yourcompany.com',
    'license': 'LGPL-3',
    'description': """
Maqsam API Documentation
========================
This module provides a comprehensive system for managing and presenting 
Maqsam API documentation within Odoo.
    """,
    'depends': ['base', 'web', 'mail'],
    'data': [
        'security/maqsam_api_security.xml',
        'security/ir.model.access.csv',
        'views/maqsam_api_section_views.xml',
        'views/maqsam_api_endpoint_views.xml',
        'views/maqsam_api_parameter_views.xml',
        'views/maqsam_api_authentication_views.xml',
        'views/maqsam_api_version_views.xml',
        'views/maqsam_api_menus.xml',
        'report/maqsam_api_report.xml',
        'report/maqsam_api_report_template.xml',
        'data/maqsam_api_section_data.xml',
        'data/maqsam_api_endpoint_data.xml',
        'data/maqsam_api_parameter_data.xml',
        'data/maqsam_api_authentication_data.xml',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
    'assets': {
        'web.assets_backend': [
            'maqsam_api_docs/static/src/js/maqsam_api_docs_widget.js',
            'maqsam_api_docs/static/src/scss/maqsam_api_docs.scss',
        ],
        'web.assets_qweb': [
            'maqsam_api_docs/static/src/xml/maqsam_api_docs_templates.xml',
        ],
    },
}
